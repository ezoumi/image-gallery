let i=0;
let timer;
let time=2000; 

//Image gallery array
const gallery = [
    "./images/gallery/1.jpg",
    "./images/gallery/2.jpg",
    "./images/gallery/3.jpg",
    "./images/gallery/4.jpg",
    "./images/gallery/5.jpg",
];

   // Main function for the alternation of images in image gallery
    function StartSlideShow(){
    let img = document.getElementById("mainImage");
    img.src = gallery[i];             //show the right image from the gallery
    if(i<gallery.length-1){
        i++;
        console.log(i);
    }else{
        i=0;
        console.log(i);
    }
    timer = setTimeout(StartSlideShow, time);
    }

    // Stop the alternation of images in image gallery
    function stopSlideShow(){
        clearTimeout(timer);
    }

// Every time you click a thumbnail
    function thumbClick(a){
        stopSlideShow();
        let img = document.getElementById("mainImage");
        img.src = gallery[a-1];

    }

// For button previous image
    function previousImg(){ 
        stopSlideShow();
        let img = document.getElementById("mainImage");
       img.src = gallery[i];
        if(i>0){
            i--;
            console.log(i);
        }else{
            i=gallery.length-1;
            console.log(i);
        }

    }
// For button next image
    function nextImg(){ 
        stopSlideShow();
        let img = document.getElementById("mainImage");
       img.src = gallery[i];
        if(i<gallery.length-1){
            i++;
            console.log(i);
        }else{
            i=0;
            console.log(i);
        }

    }


// Every time the page is loaded, call function StartSlideShow
    window.onload = StartSlideShow();